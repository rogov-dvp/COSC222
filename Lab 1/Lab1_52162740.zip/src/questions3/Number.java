package questions3;

public abstract class Number {
	
	public String toString() {
		return "";
	}
	
	public double magnitude() {
		return 0.0;
	}
}
